#include "OS67.h"

OS67_I2CDriver::OS67_I2CDriver(CommLib *comm) 
	: I2CDriver(comm, PIN_IRQ, OS67_I2C_SLAVE_ADDR)
{
	addr = new DigitalOut(PIN_ADDR, 0);
	i2csel = new DigitalOut(PIN_I2CSEL, 1);
}

OS67_SPIDriver::OS67_SPIDriver(CommLib *comm, int spiFreq)
	: SPIDriver(comm, PIN_IRQ, PIN_CSB, spiFreq)
{
	i2csel = new DigitalOut(PIN_I2CSEL, 0);
}

void OS67_enable(Driver *driver)
{
	int ret = 0;
	uint8_t reg[OS67_INTERRUPT_STATUS_CNT];
	/* Shutdown Clear 
	reg[0] = reg[1] = OS67_SYSTEM_CONF_1;
	ret |= driver->ReadReg(reg+1, 1);
	reg[1] &= ~OS67_SHDN;
	ret |= driver->WriteReg(reg, 2);
	*/
	/* Flush Fifo */
	reg[0] = reg[1] = OS67_FIFO_CONF_2;
	ret |= driver->ReadReg(reg+1, 1);
	reg[1] |= OS67_FLUSH_FIFO;
	ret |= driver->WriteReg(reg, 2);

	/* Clear Interrupt Status */
	reg[0] = OS67_INTERRUPT_STATUS_1;
	ret |= driver->ReadReg(reg, OS67_INTERRUPT_STATUS_CNT);
	driver->commLib->debugPrint("OS67 %s status : %02x %02x %02x %02x %02x\r\n", __func__, 
			reg[0], reg[1], reg[2], reg[3], reg[4]);

	/* Enable Interrupt */
	driver->enable_irq();

	if ( ret != 0 )
		driver->commLib->debugPrint("OS67 %s Error\r\n", __func__);
}

void OS67_disable(Driver *driver)
{
	int ret = 0;
	uint8_t reg[2];

	//driver->commLib->debugPrint("OS67 %s called\r\n", __func__);

	/* Disable Interrupt */
	driver->disable_irq();

	/* Shutdown Set
	reg[0] = reg[1] = OS67_SYSTEM_CONF_1;
	ret |= driver->ReadReg(reg+1, 1);
	reg[1] |= OS67_SHDN;
	ret |= driver->WriteReg(reg, 2);
 */
	if ( ret != 0 )
		driver->commLib->debugPrint("OS67 %s Error\r\n", __func__);
}

/*****************************
 * OS67 Packet Structure
 * [0] - HEADER
 * [1] - MSB of Length of Data Packet
 * [2] - LSB of Length of Data Packet
 * [3] - Interrupt Status 1
 * [4] - Interrupt Status 2
 * [3+OS67_INTERRUPT_STATUS_CNT] - Sample Count MSB
 * [4+OS67_INTERRUPT_STATUS_CNT] - Sample Count LSB
 * [5+OS67_INTERRUPT_STATUS_CNT:] - FIFO Data
 *****************************/

void OS67_read_fifo(Driver *driver)
{
	uint8_t dataBuf[OS67_FIFO_SIZE*3+6] = {0, };
	int txSize = 0;
	int fifo_cnt = 0;
	int ret = 0;

	dataBuf[0] = COMM_DATA_HEADER;
	/*Read Status*/
	dataBuf[3] = OS67_INTERRUPT_STATUS_1;
	ret |= driver->ReadReg(dataBuf+3, OS67_INTERRUPT_STATUS_CNT);

	/*Read Fifo OVF*/
	dataBuf[3+OS67_INTERRUPT_STATUS_CNT] = OS67_OVF;
	ret |= driver->ReadReg(dataBuf+3+OS67_INTERRUPT_STATUS_CNT, 2);
	if (dataBuf[3+OS67_INTERRUPT_STATUS_CNT] & 0x3E) {
		dataBuf[0] = COMM_DATA_OVF_HEADER;
	}
	/*Read Fifo Cnt*/
	fifo_cnt = ((dataBuf[3+OS67_INTERRUPT_STATUS_CNT] & 0xc0) << 2) | dataBuf[4+OS67_INTERRUPT_STATUS_CNT];
	dataBuf[3+OS67_INTERRUPT_STATUS_CNT] = (fifo_cnt>>8)&0xff;
	dataBuf[4+OS67_INTERRUPT_STATUS_CNT] = fifo_cnt&0xff;

	dataBuf[5+OS67_INTERRUPT_STATUS_CNT] = OS67_FIFO_DATA;
	ret |= driver->ReadReg(dataBuf+5+OS67_INTERRUPT_STATUS_CNT, fifo_cnt*4);	// 4B words: 9b tag and 20b data

	txSize = 5+OS67_INTERRUPT_STATUS_CNT + fifo_cnt*4;
	dataBuf[1] = (txSize>>8)&0xff;
	dataBuf[2] = txSize & 0xff;
	driver->commLib->serialWrite(dataBuf, txSize);

	if ( ret != 0 )
		driver->commLib->debugPrint("OS67 %s Error\r\n", __func__);
}


