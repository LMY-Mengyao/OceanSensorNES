#ifndef _OS67_H_
#define _OS67_H_

#include "I2CDriver.h"
#include "SPIDriver.h"

#define PIN_ADDR	P3_0	
#define PIN_IRQ		P5_4		
#define PIN_CSB		P3_0
#define PIN_I2CSEL	P5_3

#define OS67_I2C_SLAVE_ADDR	(0x71<<1)

#define OS67_INTERRUPT_STATUS_CNT		2
#define OS67_INTERRUPT_STATUS_1			0x00
#define OS67_OVF						0x03
#define OS67_FIFO_DATA_CNT				0x04 
#define OS67_FIFO_DATA					0x08

#define OS67_FIFO_CONF_2				0x09
#define OS67_FLUSH_FIFO			(1<<4)

#define OS67_SYSTEM_CONF_1				0x0D
#define OS67_SHDN				(1<<1)

#define OS67_FIFO_SIZE			512

void OS67_enable(Driver *driver);
void OS67_disable(Driver *driver);
void OS67_read_fifo(Driver *driver);

class OS67_I2CDriver : public I2CDriver
{
public:
	OS67_I2CDriver(CommLib *comm);
	void enable(){OS67_enable(this);};		
	void disable(){OS67_disable(this);};		
	void read_fifo(){OS67_read_fifo(this);};

private:
	DigitalOut *i2csel;
	DigitalOut *addr;
};

class OS67_SPIDriver : public SPIDriver
{
public:
	OS67_SPIDriver(CommLib *comm, int spiFreq);
	void enable(){OS67_enable(this);};		
	void disable(){OS67_disable(this);};		
	void read_fifo(){OS67_read_fifo(this);};

private:
	DigitalOut *i2csel;
};

#endif

